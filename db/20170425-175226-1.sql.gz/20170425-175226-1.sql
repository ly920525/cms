-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : whedencms
-- 
-- Part : #1
-- Date : 2017-04-25 17:52:26
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `wd_about`
-- -----------------------------
DROP TABLE IF EXISTS `wd_about`;
CREATE TABLE `wd_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `img` varchar(150) NOT NULL COMMENT '图片',
  `img_title` varchar(50) NOT NULL COMMENT '图片标题',
  `img_content` varchar(200) NOT NULL COMMENT '图片内容',
  `state` tinyint(255) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_about`
-- -----------------------------
INSERT INTO `wd_about` VALUES ('13', '我们是谁', '&lt;p&gt;维登科技是一家专注于电子商务和移动互联网运营的科技型服务公司。公司依托互联网的创业生态体系，在零售电商、&lt;/p&gt;&lt;p&gt;O2O领域及移动新互联网方向积极探索，开拓进取。成立以来，秉承“创新、务实、诚信，共赢”的价值观，以用户需求为核心，&lt;/p&gt;&lt;p&gt;聚焦客户的关注点，提供有竞争力的解决方案和服务，为客户创造最大价值。公司专注于网站定制、企业网站建设、手机移动网站建设、&lt;/p&gt;&lt;p&gt;手机APP定制开发、应用系统开发、电商运营、移动互联网等相关服务，为企业提供全球化互联网解决方案。&lt;/p&gt;&lt;p&gt;我们的理念：聚焦客户的关注点，提供有竞争力的解决方案和服务，为客户创造最大价值。&lt;/p&gt;&lt;p&gt;我们的宗旨：创新、务实、诚信，共赢。&lt;/p&gt;&lt;p&gt;我们的追求：塑企业形象，创优质品牌。&lt;/p&gt;', '2017-04-14/58f080a749c7f.gif', '定制打造', '针对不同企业状况、客户特殊需求等量身打造，从专业化的建站方案定制，独一无二的视觉效果设计，\r\n                        到易于SEO优化的规范化代码编写，易于操作的人性化管理后台，无不体现“定制”的意义。', '1');
INSERT INTO `wd_about` VALUES ('14', '我们是谁', '', '2017-04-17/58f424cf89f0d.jpg', '创新设计', '为客户定制适合自己的互联网形象，\r\n                        尊重访问者视觉体验和浏览习惯，用户体验友好，\r\n                        注重信息架构分析，界面设计、互动设计和\r\n                        内容制作，为客户提供高价值的平台。', '1');
INSERT INTO `wd_about` VALUES ('15', '我们是谁', '&lt;p&gt;维登科技是一家专注于电子商务和移动互联网运营的科技型服务公司。公司依托互联网的创业生态体系，在零售电商、&lt;/p&gt;&lt;p&gt;O2O领域及移动新互联网方向积极探索，开拓进取。成立以来，秉承“创新、务实、诚信，共赢”的价值观，以用户需求为核心，&lt;/p&gt;&lt;p&gt;聚焦客户的关注点，提供有竞争力的解决方案和服务，为客户创造最大价值。公司专注于网站定制、企业网站建设、手机移动网站建设、&lt;/p&gt;&lt;p&gt;手机APP定制开发、应用系统开发、电商运营、移动互联网等相关服务，为企业提供全球化互联网解决方案。&lt;/p&gt;&lt;p&gt;我们的理念：聚焦客户的关注点，提供有竞争力的解决方案和服务，为客户创造最大价值。&lt;/p&gt;&lt;p&gt;我们的宗旨：创新、务实、诚信，共赢。&lt;/p&gt;&lt;p&gt;我们的追求：塑企业形象，创优质品牌。&lt;/p&gt;', '2017-04-17/58f4240321b15.jpg', '诚信务实', '全网是一个新概念，是互联网时代的必然产物，更是企业在未来几年内的生存之道。\r\n维登为客户提供全方位全网开发。网站建设、微站设计、微信公众平台开发，同时完整的将互联网各平台结合，\r\n实现一站式管理。', '1');

-- -----------------------------
-- Table structure for `wd_about_list`
-- -----------------------------
DROP TABLE IF EXISTS `wd_about_list`;
CREATE TABLE `wd_about_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `classification` varchar(100) NOT NULL COMMENT '分类',
  `img_url` varchar(150) NOT NULL COMMENT '图片',
  `content` varchar(200) NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_about_list`
-- -----------------------------
INSERT INTO `wd_about_list` VALUES ('17', '我们是谁', '沟通', '2017-04-14/58f08775494af.png', '&lt;p&gt;您可以拨打我们的电话,联系我们说出您的需求，我们会根据已确认的设计稿进行每一个页面的制作&lt;/p&gt;');
INSERT INTO `wd_about_list` VALUES ('18', '我们的服务', '互联', '2017-04-14/58f087b06f60f.png', '&lt;p&gt;我们提供全网服务器,支持VPN全球用户访问&lt;/p&gt;');
INSERT INTO `wd_about_list` VALUES ('19', '我们的服务', '在线', '2017-04-14/58f08807c64af.png', '&lt;p&gt;随时随地在线沟通，共同商榷网站建设&lt;/p&gt;');
INSERT INTO `wd_about_list` VALUES ('20', '我们是谁', '云端', '2017-04-14/58f0883136bcf.png', '&lt;p&gt;云平台，云储存，云服务，让数据更加安全&lt;/p&gt;');
INSERT INTO `wd_about_list` VALUES ('21', '我们是谁', '兼容', '2017-04-14/58f0885fca717.png', '&lt;p&gt;支持手机访问网页，完美兼容&lt;/p&gt;');
INSERT INTO `wd_about_list` VALUES ('22', '我们是谁', '咨询', '2017-04-14/58f088934fe27.png', '&lt;p&gt;现在立即致电13637848756,开始属于您的网站之旅！&lt;/p&gt;');

-- -----------------------------
-- Table structure for `wd_admin`
-- -----------------------------
DROP TABLE IF EXISTS `wd_admin`;
CREATE TABLE `wd_admin` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '管理员表',
  `username` varchar(50) NOT NULL COMMENT '管理员用户名',
  `password` varchar(50) NOT NULL COMMENT '登陆密码',
  `level` int(1) NOT NULL DEFAULT '1' COMMENT '等级1，2，3',
  `mail` varchar(20) NOT NULL DEFAULT '0',
  `numb` varchar(30) NOT NULL DEFAULT '0' COMMENT '手机号码',
  `head_url` varchar(50) NOT NULL DEFAULT '0' COMMENT '管理员头像',
  `createtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在线（0，1）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_admin`
-- -----------------------------
INSERT INTO `wd_admin` VALUES ('19', 'admin', 'admin', '1', '710201459@qq.com', '13637848756', '0', '2017-04-22 15:59:27', '0');
INSERT INTO `wd_admin` VALUES ('20', '1', '11111', '1', '0', '0', '0', '0000-00-00 00:00:00', '1');

-- -----------------------------
-- Table structure for `wd_backstage`
-- -----------------------------
DROP TABLE IF EXISTS `wd_backstage`;
CREATE TABLE `wd_backstage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `icon` varchar(50) NOT NULL COMMENT '小图标',
  `title` varchar(100) NOT NULL,
  `fangfa` varchar(100) NOT NULL,
  `create_time` datetime NOT NULL,
  `sort` int(11) NOT NULL,
  `state` varchar(4) NOT NULL COMMENT '状态',
  `active` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_backstage`
-- -----------------------------
INSERT INTO `wd_backstage` VALUES ('20', '0', 'icon-home', '后台首页', 'index/info', '2017-04-18 17:08:31', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('23', '43', 'icon-caret-right', '权限管理', 'user/level', '2017-04-18 16:55:09', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('24', '0', 'icon-gears', '系统设置', '/', '2017-04-18 18:18:43', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('25', '24', 'icon-caret-right', '后台栏目', 'Backstage/backstage', '2017-04-18 15:03:40', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('26', '0', 'icon-gear', '基本设置', '/', '2017-04-18 16:33:33', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('27', '26', 'icon-caret-right', '网站信息', 'Contact/website', '2017-04-18 16:35:07', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('28', '26', 'icon-caret-right', '联系我们', 'Contact/contact', '2017-04-18 15:01:59', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('29', '26', 'icon-caret-right', '首页轮播', 'column/column', '2017-04-18 15:02:51', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('30', '26', 'icon-caret-right', '导航菜单', 'column/cate', '2017-04-18 15:06:39', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('31', '0', 'icon-th-large', '关于维登', '/', '2017-04-18 17:10:58', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('32', '31', 'icon-caret-right', '关于我们', 'about/about', '2017-04-18 15:09:46', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('33', '31', 'icon-caret-right', '列表', 'about/lists', '2017-04-18 15:10:48', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('34', '0', 'icon-sitemap', '服务管理', '/', '2017-04-18 15:12:45', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('35', '34', 'icon-caret-right', '所以服务', 'service/service', '2017-04-18 15:18:42', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('36', '34', 'icon-caret-right', '列表', 'service/lists', '2017-04-18 16:36:25', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('37', '0', 'icon-file-text', '新闻管理', '/', '2017-04-18 16:37:08', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('38', '37', 'icon-caret-right', '所有新闻', 'news/news', '2017-04-18 16:37:36', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('39', '37', 'icon-caret-right', '新闻分类', 'news/cate', '2017-04-18 16:39:45', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('40', '0', 'icon-th', '案例管理', '/', '2017-04-18 16:42:45', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('41', '40', 'icon-caret-right', '所有案例', 'case/index', '2017-04-18 16:43:28', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('42', '40', 'icon-caret-right', '案例分类', 'case/casetype', '2017-04-18 16:44:16', '0', '是', 'active');
INSERT INTO `wd_backstage` VALUES ('43', '0', 'icon-group', '账号管理', '/', '2017-04-18 16:45:47', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('44', '43', 'icon-caret-right', '账号信息', 'user/user', '2017-04-18 16:46:19', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('45', '43', 'icon-caret-right', '修改密码', 'user/pass', '2017-04-18 16:47:50', '0', '是', '');
INSERT INTO `wd_backstage` VALUES ('47', '0', 'icon-envelope', '留言板', 'message/message', '2017-04-18 17:00:07', '0', '是', '');

-- -----------------------------
-- Table structure for `wd_backstage_icon`
-- -----------------------------
DROP TABLE IF EXISTS `wd_backstage_icon`;
CREATE TABLE `wd_backstage_icon` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `icon` varchar(50) NOT NULL COMMENT '小图标',
  `icon_title` varchar(50) NOT NULL COMMENT '图标中文描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_backstage_icon`
-- -----------------------------
INSERT INTO `wd_backstage_icon` VALUES ('1', 'icon-signal', '图表');
INSERT INTO `wd_backstage_icon` VALUES ('2', 'icon-download', '备份');
INSERT INTO `wd_backstage_icon` VALUES ('3', 'icon-map-marker', '定位');
INSERT INTO `wd_backstage_icon` VALUES ('4', 'icon-reply', '返回');
INSERT INTO `wd_backstage_icon` VALUES ('5', 'icon-sitemap', '分支');
INSERT INTO `wd_backstage_icon` VALUES ('6', 'icon-unlock-alt', '开锁');
INSERT INTO `wd_backstage_icon` VALUES ('7', 'icon-trash-o', '垃圾桶');
INSERT INTO `wd_backstage_icon` VALUES ('8', 'icon-phone-square', '联系我们');
INSERT INTO `wd_backstage_icon` VALUES ('9', 'icon-link', '链接');
INSERT INTO `wd_backstage_icon` VALUES ('10', 'icon-list-ul', '列表1');
INSERT INTO `wd_backstage_icon` VALUES ('11', 'icon-th', '列表2');
INSERT INTO `wd_backstage_icon` VALUES ('12', 'icon-th-large', '列表3');
INSERT INTO `wd_backstage_icon` VALUES ('13', 'icon-comments', '留言1');
INSERT INTO `wd_backstage_icon` VALUES ('14', 'icon-envelope', '留言2');
INSERT INTO `wd_backstage_icon` VALUES ('15', 'icon-gear', '设置1');
INSERT INTO `wd_backstage_icon` VALUES ('16', 'icon-gears', '设置2');
INSERT INTO `wd_backstage_icon` VALUES ('17', 'icon-desktop', '首页');
INSERT INTO `wd_backstage_icon` VALUES ('18', 'icon-home', '首页2');
INSERT INTO `wd_backstage_icon` VALUES ('19', 'icon-lock', '锁定');
INSERT INTO `wd_backstage_icon` VALUES ('21', 'icon-image', '图片');
INSERT INTO `wd_backstage_icon` VALUES ('22', 'icon-power-off', '退出');
INSERT INTO `wd_backstage_icon` VALUES ('23', 'icon-folder-open-o', '文件1');
INSERT INTO `wd_backstage_icon` VALUES ('24', 'icon-folder-open', '文件2');
INSERT INTO `wd_backstage_icon` VALUES ('25', 'icon-file-text', '新闻');
INSERT INTO `wd_backstage_icon` VALUES ('26', 'icon-group', '用户管理');
INSERT INTO `wd_backstage_icon` VALUES ('27', 'icon-cloud', '云数据');
INSERT INTO `wd_backstage_icon` VALUES ('28', 'icon-pencil-square-o', '修改');
INSERT INTO `wd_backstage_icon` VALUES ('29', 'icon-caret-right', '二级栏目');

-- -----------------------------
-- Table structure for `wd_case`
-- -----------------------------
DROP TABLE IF EXISTS `wd_case`;
CREATE TABLE `wd_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL COMMENT '案例标题',
  `text` text NOT NULL COMMENT '案例内容',
  `img_url` varchar(100) NOT NULL COMMENT '案例链接',
  `issuer` varchar(50) NOT NULL COMMENT '案例分类',
  `casetime` varchar(20) NOT NULL,
  `case_url` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='维登案例表';

-- -----------------------------
-- Records of `wd_case`
-- -----------------------------
INSERT INTO `wd_case` VALUES ('7', '测试', '测试', '2017-04-11/58ecad0da6731.jpg', '1', '1491905805', '测试');
INSERT INTO `wd_case` VALUES ('9', '123', '123', '2017-04-17/58f416b729fe5.jpg', '1', '1492391607', '123');

-- -----------------------------
-- Table structure for `wd_case_type`
-- -----------------------------
DROP TABLE IF EXISTS `wd_case_type`;
CREATE TABLE `wd_case_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `start` tinyint(1) NOT NULL,
  `sort` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='案例分类表';

-- -----------------------------
-- Records of `wd_case_type`
-- -----------------------------
INSERT INTO `wd_case_type` VALUES ('1', '测试1', '0', '2');
INSERT INTO `wd_case_type` VALUES ('3', '123', '0', '1');

-- -----------------------------
-- Table structure for `wd_cate`
-- -----------------------------
DROP TABLE IF EXISTS `wd_cate`;
CREATE TABLE `wd_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `fangfa` varchar(100) NOT NULL,
  `create_time` datetime NOT NULL,
  `sort` int(11) NOT NULL,
  `state` tinyint(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_cate`
-- -----------------------------
INSERT INTO `wd_cate` VALUES ('10', '0', '首页', 'index/index', '2017-04-12 12:00:39', '0', '0');
INSERT INTO `wd_cate` VALUES ('11', '0', '关于维登', 'about/about', '2017-04-13 14:17:35', '0', '0');
INSERT INTO `wd_cate` VALUES ('12', '11', '招聘信息', 'about/zhaopin', '2017-04-17 10:44:25', '0', '0');
INSERT INTO `wd_cate` VALUES ('13', '11', '公司环境', 'about/lists', '2017-04-18 17:42:46', '0', '0');
INSERT INTO `wd_cate` VALUES ('14', '0', '服务范围', 'Service/service', '2017-04-13 14:36:39', '0', '0');
INSERT INTO `wd_cate` VALUES ('15', '0', '新闻资讯', 'news/news', '2017-04-17 09:55:15', '0', '0');
INSERT INTO `wd_cate` VALUES ('16', '0', '项目案例', 'Cases/cases', '2017-04-17 15:55:33', '0', '0');
INSERT INTO `wd_cate` VALUES ('18', '0', '联系我们', 'Contact/contact', '2017-04-17 11:37:33', '0', '0');
INSERT INTO `wd_cate` VALUES ('19', '0', '维登公益', 'public/error', '2017-04-18 17:41:36', '0', '0');

-- -----------------------------
-- Table structure for `wd_column`
-- -----------------------------
DROP TABLE IF EXISTS `wd_column`;
CREATE TABLE `wd_column` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `id_sort` int(10) NOT NULL COMMENT '排序',
  `name` varchar(150) NOT NULL COMMENT '标题',
  `img` varchar(100) NOT NULL COMMENT '图片',
  `describe` varchar(150) NOT NULL COMMENT '描述',
  `create_time` datetime NOT NULL COMMENT '更新时间',
  `state` varchar(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_column`
-- -----------------------------
INSERT INTO `wd_column` VALUES ('17', '0', '轮播2', '2017-04-14/58f02aa291cd7.jpg', '168168', '2017-04-14 10:59:28', '否');
INSERT INTO `wd_column` VALUES ('18', '0', '轮播2', '2017-04-14/58f02af9be3c7.gif', '888', '2017-04-14 09:51:04', '是');
INSERT INTO `wd_column` VALUES ('19', '0', '轮播2', '2017-04-14/58f02b87b1c8f.jpg', '888', '2017-04-14 10:14:53', '是');
INSERT INTO `wd_column` VALUES ('20', '0', '轮播2', '2017-04-14/58f02c625c177.jpg', '888888', '2017-04-14 10:15:20', '否');
INSERT INTO `wd_column` VALUES ('21', '0', '轮播2', '2017-04-14/58f031a97f00f.gif', '8888', '2017-04-14 10:19:21', '是');
INSERT INTO `wd_column` VALUES ('22', '0', '轮播2', '2017-04-14/58f031ce027df.jpg', '8888', '2017-04-14 10:19:58', '否');

-- -----------------------------
-- Table structure for `wd_contact`
-- -----------------------------
DROP TABLE IF EXISTS `wd_contact`;
CREATE TABLE `wd_contact` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '联系我们表',
  `name` varchar(20) NOT NULL COMMENT '联系方式名',
  `phone` int(11) NOT NULL COMMENT '手机',
  `telephone` varchar(15) NOT NULL COMMENT '电话',
  `qq` varchar(50) NOT NULL COMMENT 'QQ',
  `email` varchar(50) NOT NULL COMMENT '电子邮箱',
  `address` varchar(100) NOT NULL COMMENT '地址',
  `information` varchar(150) NOT NULL COMMENT '信息',
  `create_time` datetime NOT NULL COMMENT '发送时间',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_contact`
-- -----------------------------
INSERT INTO `wd_contact` VALUES ('1', '罗总', '2147483647', '0769-89865500', '710201459', '710201459@qq.com', '东莞市南城商务大厦', '维登科技', '2017-04-12 10:45:53', '1');

-- -----------------------------
-- Table structure for `wd_lianxi`
-- -----------------------------
DROP TABLE IF EXISTS `wd_lianxi`;
CREATE TABLE `wd_lianxi` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '联系我们表',
  `name` varchar(20) NOT NULL COMMENT '联系方式名',
  `address` varchar(100) NOT NULL COMMENT '属性',
  `mail` varchar(100) NOT NULL COMMENT '图片',
  `phone` varchar(100) NOT NULL COMMENT '链接',
  `qq` varchar(100) NOT NULL,
  `weixin_img` varchar(100) NOT NULL,
  `weibo` varchar(100) NOT NULL,
  `Mobile` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wd_link`
-- -----------------------------
DROP TABLE IF EXISTS `wd_link`;
CREATE TABLE `wd_link` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `link_img` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `short` int(3) NOT NULL,
  `title` varchar(150) NOT NULL,
  `create_time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_link`
-- -----------------------------
INSERT INTO `wd_link` VALUES ('1', 'index/index', '2017-04-17/58f4222e3b155.jpg', '1', '0', '123', '0000-00-00 00:00:00');
INSERT INTO `wd_link` VALUES ('2', 'index/index', '2017-04-17/58f4227c65ced.jpg', '2', '0', '123', '0000-00-00 00:00:00');
INSERT INTO `wd_link` VALUES ('3', 'index/index', '2017-04-17/58f422d395a8d.jpg', '1', '0', '1', '1492394707');

-- -----------------------------
-- Table structure for `wd_log`
-- -----------------------------
DROP TABLE IF EXISTS `wd_log`;
CREATE TABLE `wd_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `do` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `type` int(5) NOT NULL,
  `state` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_log`
-- -----------------------------
INSERT INTO `wd_log` VALUES ('14', '1231231', '加入到了管理员', '2017-04-14 16:12:35', '0', '3');
INSERT INTO `wd_log` VALUES ('15', '1', '退出了后台', '2017-04-14 16:12:49', '0', '2');
INSERT INTO `wd_log` VALUES ('16', 'admin', '登陆了后台', '2017-04-14 16:13:03', '0', '1');
INSERT INTO `wd_log` VALUES ('17', 'admin', '退出了后台', '2017-04-14 17:34:28', '0', '2');
INSERT INTO `wd_log` VALUES ('18', '2', '登陆了后台', '2017-04-14 17:34:34', '0', '1');
INSERT INTO `wd_log` VALUES ('19', '2', '退出了后台', '2017-04-14 17:36:08', '0', '2');
INSERT INTO `wd_log` VALUES ('20', '2', '登陆了后台', '2017-04-14 17:36:12', '0', '1');
INSERT INTO `wd_log` VALUES ('21', '2', '退出了后台', '2017-04-14 17:37:13', '0', '2');
INSERT INTO `wd_log` VALUES ('22', '2', '登陆了后台', '2017-04-14 17:37:18', '0', '1');
INSERT INTO `wd_log` VALUES ('23', '2', '退出了后台', '2017-04-14 17:37:24', '0', '2');
INSERT INTO `wd_log` VALUES ('24', '1', '登陆了后台', '2017-04-14 17:37:27', '0', '1');
INSERT INTO `wd_log` VALUES ('25', '1', '登陆了后台', '2017-04-15 09:09:38', '0', '1');
INSERT INTO `wd_log` VALUES ('26', '1', '把管理员Array删掉了', '2017-04-15 10:23:19', '1', '2');
INSERT INTO `wd_log` VALUES ('27', '1', '把管理员删掉了', '2017-04-15 10:24:27', '1', '2');
INSERT INTO `wd_log` VALUES ('28', '12345', '加入到了管理员', '2017-04-15 10:25:46', '0', '3');
INSERT INTO `wd_log` VALUES ('29', '1', '把管理员删掉了', '2017-04-15 10:25:53', '1', '2');
INSERT INTO `wd_log` VALUES ('30', '123456', '加入到了管理员', '2017-04-15 10:27:23', '0', '3');
INSERT INTO `wd_log` VALUES ('31', '1', '把管理员删掉了', '2017-04-15 10:27:29', '1', '2');
INSERT INTO `wd_log` VALUES ('32', '12345', '加入到了管理员', '2017-04-15 10:28:48', '0', '3');
INSERT INTO `wd_log` VALUES ('33', '1', '把管理员删掉了', '2017-04-15 10:28:55', '1', '2');
INSERT INTO `wd_log` VALUES ('34', '1', '把管理员admin删掉了', '2017-04-15 10:29:24', '1', '2');
INSERT INTO `wd_log` VALUES ('35', '1', '删掉了的留言', '2017-04-15 10:34:18', '1', '2');
INSERT INTO `wd_log` VALUES ('36', '1', '删掉了的留言', '2017-04-15 10:35:08', '1', '2');
INSERT INTO `wd_log` VALUES ('37', '李勇', '访问者给我们留言了', '2017-04-15 10:39:12', '1', '1');
INSERT INTO `wd_log` VALUES ('38', '1', '删掉了的留言', '2017-04-15 10:40:58', '1', '2');
INSERT INTO `wd_log` VALUES ('39', '1', '删掉了李勇的留言', '2017-04-15 10:43:33', '1', '2');
INSERT INTO `wd_log` VALUES ('40', '1', '修改了[]信息', '2017-04-15 11:09:20', '0', '3');
INSERT INTO `wd_log` VALUES ('41', '12345', '加入到了管理员', '2017-04-15 11:13:30', '0', '3');
INSERT INTO `wd_log` VALUES ('42', '1', '修改了[]信息', '2017-04-15 11:22:32', '0', '3');
INSERT INTO `wd_log` VALUES ('43', '1', '修改了[]信息', '2017-04-15 11:22:58', '0', '3');
INSERT INTO `wd_log` VALUES ('44', '1', '修改了[]信息', '2017-04-15 11:28:31', '0', '0');
INSERT INTO `wd_log` VALUES ('45', '1', '修改了[]信息', '2017-04-15 11:30:25', '0', '0');
INSERT INTO `wd_log` VALUES ('46', '1', '修改了[12345]信息', '2017-04-15 11:37:04', '0', '0');
INSERT INTO `wd_log` VALUES ('47', '1', '修改了[1]信息', '2017-04-15 11:37:53', '0', '0');
INSERT INTO `wd_log` VALUES ('48', '1', '退出了后台', '2017-04-15 11:38:42', '0', '2');
INSERT INTO `wd_log` VALUES ('49', '1', '登陆了后台', '2017-04-15 11:38:49', '0', '1');
INSERT INTO `wd_log` VALUES ('50', '1', '登陆了后台', '2017-04-15 14:29:20', '0', '1');
INSERT INTO `wd_log` VALUES ('51', '1', '登陆了后台', '2017-04-15 14:39:20', '0', '1');
INSERT INTO `wd_log` VALUES ('52', '1', '删掉了[李勇]的留言', '2017-04-15 14:39:48', '1', '2');
INSERT INTO `wd_log` VALUES ('53', '1', '退出了后台', '2017-04-15 14:51:25', '0', '2');
INSERT INTO `wd_log` VALUES ('54', '1', '登陆了后台', '2017-04-15 14:51:36', '0', '1');
INSERT INTO `wd_log` VALUES ('55', 'admin', '加入到了管理员', '2017-04-15 14:52:12', '0', '3');
INSERT INTO `wd_log` VALUES ('56', '1', '退出了后台', '2017-04-15 14:52:17', '0', '2');
INSERT INTO `wd_log` VALUES ('57', 'admin', '登陆了后台', '2017-04-15 14:52:23', '0', '1');
INSERT INTO `wd_log` VALUES ('58', 'admin', '退出了后台', '2017-04-15 15:01:39', '0', '2');
INSERT INTO `wd_log` VALUES ('59', '1', '登陆了后台', '2017-04-17 09:12:47', '0', '1');
INSERT INTO `wd_log` VALUES ('60', '1', '数据库≮20170418-095051-*.sql*≯删除成功', '2017-04-18 16:02:00', '1', '2');
INSERT INTO `wd_log` VALUES ('61', '1', '还原了≮20170418-160237-*.sql*≯数据库', '2017-04-18 16:10:49', '0', '0');
INSERT INTO `wd_log` VALUES ('62', '1', '备份了数据库', '2017-04-18 16:11:08', '0', '1');
INSERT INTO `wd_log` VALUES ('63', '1', '数据库≮20170418-160237-*.sql*≯删除成功', '2017-04-18 16:12:26', '1', '2');
INSERT INTO `wd_log` VALUES ('64', '1', '登陆了后台', '2017-04-18 17:30:45', '0', '1');
INSERT INTO `wd_log` VALUES ('65', '1', '退出了后台', '2017-04-18 19:05:25', '0', '2');
INSERT INTO `wd_log` VALUES ('66', 'admin', '登陆了后台', '2017-04-18 19:05:31', '0', '1');
INSERT INTO `wd_log` VALUES ('67', '1', '登陆了后台', '2017-04-20 09:42:41', '0', '1');
INSERT INTO `wd_log` VALUES ('68', '1', '登陆了后台', '2017-04-20 10:12:19', '0', '1');
INSERT INTO `wd_log` VALUES ('69', '1', '登陆了后台', '2017-04-20 14:43:46', '0', '1');
INSERT INTO `wd_log` VALUES ('70', '1', '登陆了后台', '2017-04-21 09:13:11', '0', '1');
INSERT INTO `wd_log` VALUES ('71', '1', '登陆了后台', '2017-04-21 10:50:07', '0', '1');
INSERT INTO `wd_log` VALUES ('72', '1', '退出了后台', '2017-04-21 11:51:08', '0', '2');
INSERT INTO `wd_log` VALUES ('73', '1', '登陆了后台', '2017-04-21 11:55:00', '0', '1');
INSERT INTO `wd_log` VALUES ('74', '1', '退出了后台', '2017-04-21 14:04:20', '0', '2');
INSERT INTO `wd_log` VALUES ('75', 'admin', '登陆了后台', '2017-04-21 14:04:32', '0', '1');
INSERT INTO `wd_log` VALUES ('76', 'admin', '退出了后台', '2017-04-21 15:28:44', '0', '2');
INSERT INTO `wd_log` VALUES ('77', '1', '登陆了后台', '2017-04-21 15:28:49', '0', '1');
INSERT INTO `wd_log` VALUES ('78', '1', '退出了后台', '2017-04-21 15:48:49', '0', '2');
INSERT INTO `wd_log` VALUES ('79', '1', '登陆了后台', '2017-04-21 15:48:55', '0', '1');
INSERT INTO `wd_log` VALUES ('80', '1', '登陆了后台', '2017-04-22 09:24:11', '0', '1');
INSERT INTO `wd_log` VALUES ('81', '留言人', '访问者给我们留言了', '2017-04-22 15:45:57', '1', '1');
INSERT INTO `wd_log` VALUES ('82', '留言人', '访问者给我们留言了', '2017-04-22 15:45:59', '1', '1');
INSERT INTO `wd_log` VALUES ('83', '留言人', '访问者给我们留言了', '2017-04-22 15:46:01', '1', '1');
INSERT INTO `wd_log` VALUES ('84', '留言人', '访问者给我们留言了', '2017-04-22 15:46:04', '1', '1');
INSERT INTO `wd_log` VALUES ('85', '1', '把管理员1删掉了', '2017-04-22 15:57:02', '1', '2');
INSERT INTO `wd_log` VALUES ('86', '1', '把管理员12345删掉了', '2017-04-22 15:57:07', '1', '2');
INSERT INTO `wd_log` VALUES ('87', '1', '把管理员admin删掉了', '2017-04-22 15:57:08', '1', '2');
INSERT INTO `wd_log` VALUES ('88', '1', '退出了后台', '2017-04-22 15:57:13', '0', '2');
INSERT INTO `wd_log` VALUES ('89', '1', '登陆了后台', '2017-04-22 15:58:21', '0', '1');
INSERT INTO `wd_log` VALUES ('90', '1', '修改了[1]信息', '2017-04-22 15:58:50', '0', '0');
INSERT INTO `wd_log` VALUES ('91', 'admin', '加入到了管理员', '2017-04-22 15:59:27', '0', '3');
INSERT INTO `wd_log` VALUES ('92', '1', '把管理员1删掉了', '2017-04-22 15:59:32', '1', '2');
INSERT INTO `wd_log` VALUES ('93', '1', '退出了后台', '2017-04-22 16:00:06', '0', '2');
INSERT INTO `wd_log` VALUES ('94', '1', '登陆了后台', '2017-04-22 16:00:09', '0', '1');
INSERT INTO `wd_log` VALUES ('95', '1', '0', '2017-04-22 16:15:11', '0', '0');
INSERT INTO `wd_log` VALUES ('96', '1', '登陆了后台', '2017-04-24 16:34:43', '0', '1');
INSERT INTO `wd_log` VALUES ('97', '1', '删掉了[留言人]的留言', '2017-04-24 16:35:51', '1', '2');
INSERT INTO `wd_log` VALUES ('98', '1', '登陆了后台', '2017-04-25 17:02:07', '0', '1');
INSERT INTO `wd_log` VALUES ('99', '1', '退出了后台', '2017-04-25 17:07:06', '0', '2');
INSERT INTO `wd_log` VALUES ('100', '1', '登陆了后台', '2017-04-25 17:07:11', '0', '1');
INSERT INTO `wd_log` VALUES ('101', '1', '退出了后台', '2017-04-25 17:11:00', '0', '2');
INSERT INTO `wd_log` VALUES ('102', '1', '登陆了后台', '2017-04-25 17:11:10', '0', '1');
INSERT INTO `wd_log` VALUES ('103', '1', '登陆了后台', '2017-04-25 17:13:30', '0', '1');
INSERT INTO `wd_log` VALUES ('104', '1', '登陆了后台', '2017-04-25 17:13:49', '0', '1');
INSERT INTO `wd_log` VALUES ('105', '1', '登陆了后台', '2017-04-25 17:14:02', '0', '1');
INSERT INTO `wd_log` VALUES ('106', '1', '退出了后台', '2017-04-25 17:18:53', '0', '2');
INSERT INTO `wd_log` VALUES ('107', '1', '登陆了后台', '2017-04-25 17:24:08', '0', '1');
INSERT INTO `wd_log` VALUES ('108', '1', '退出了后台', '2017-04-25 17:26:53', '0', '2');
INSERT INTO `wd_log` VALUES ('109', '1', '登陆了后台', '2017-04-25 17:27:07', '0', '1');
INSERT INTO `wd_log` VALUES ('110', '1', '退出了后台', '2017-04-25 17:27:44', '0', '2');
INSERT INTO `wd_log` VALUES ('111', '1', '登陆了后台', '2017-04-25 17:28:01', '0', '1');
INSERT INTO `wd_log` VALUES ('112', '1', '退出了后台', '2017-04-25 17:30:14', '0', '2');
INSERT INTO `wd_log` VALUES ('113', '1', '登陆了后台', '2017-04-25 17:30:27', '0', '1');
INSERT INTO `wd_log` VALUES ('114', '1', '退出了后台', '2017-04-25 17:33:31', '0', '2');
INSERT INTO `wd_log` VALUES ('115', '1', '登陆了后台', '2017-04-25 17:33:40', '0', '1');
INSERT INTO `wd_log` VALUES ('116', '1', '退出了后台', '2017-04-25 17:36:06', '0', '2');
INSERT INTO `wd_log` VALUES ('117', '1', '登陆了后台', '2017-04-25 17:36:12', '0', '1');
INSERT INTO `wd_log` VALUES ('118', '1', '退出了后台', '2017-04-25 17:36:31', '0', '2');
INSERT INTO `wd_log` VALUES ('119', '1', '登陆了后台', '2017-04-25 17:38:28', '0', '1');
INSERT INTO `wd_log` VALUES ('120', '1', '0', '2017-04-25 17:50:07', '0', '0');

-- -----------------------------
-- Table structure for `wd_login_log`
-- -----------------------------
DROP TABLE IF EXISTS `wd_login_log`;
CREATE TABLE `wd_login_log` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `loginip` varchar(20) NOT NULL DEFAULT '0',
  `logintime` datetime NOT NULL,
  `outtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_login_log`
-- -----------------------------
INSERT INTO `wd_login_log` VALUES ('36', '1', '0.0.0.0', '2017-04-10 17:09:37', '2017-04-10 17:09:59');
INSERT INTO `wd_login_log` VALUES ('37', '1', '0.0.0.0', '2017-04-10 17:19:27', '2017-04-10 17:59:19');
INSERT INTO `wd_login_log` VALUES ('38', '1', '0.0.0.0', '2017-04-10 17:59:39', '2017-04-10 18:00:59');
INSERT INTO `wd_login_log` VALUES ('39', '1', '0.0.0.0', '2017-04-10 18:01:12', '2017-04-10 18:02:28');
INSERT INTO `wd_login_log` VALUES ('40', '1', '0.0.0.0', '2017-04-10 18:02:33', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('41', '1', '0.0.0.0', '2017-04-11 09:05:47', '2017-04-11 15:23:02');
INSERT INTO `wd_login_log` VALUES ('42', '1', '0.0.0.0', '2017-04-11 15:23:06', '2017-04-11 18:08:24');
INSERT INTO `wd_login_log` VALUES ('43', '1', '0.0.0.0', '2017-04-11 18:08:59', '2017-04-11 18:09:04');
INSERT INTO `wd_login_log` VALUES ('44', '1', '0.0.0.0', '2017-04-11 18:12:19', '2017-04-11 18:16:46');
INSERT INTO `wd_login_log` VALUES ('45', '1', '0.0.0.0', '2017-04-11 18:17:37', '2017-04-11 18:18:02');
INSERT INTO `wd_login_log` VALUES ('46', '1', '0.0.0.0', '2017-04-11 18:18:18', '2017-04-11 18:45:50');
INSERT INTO `wd_login_log` VALUES ('47', '1', '0.0.0.0', '2017-04-11 18:46:04', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('48', '1', '0.0.0.0', '2017-04-12 09:57:23', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('49', '1', '0.0.0.0', '2017-04-13 09:49:16', '2017-04-13 09:49:26');
INSERT INTO `wd_login_log` VALUES ('50', '1', '0.0.0.0', '2017-04-13 09:52:23', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('51', '1', '0.0.0.0', '2017-04-13 10:18:05', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('52', '1', '127.0.0.1', '2017-04-13 10:22:02', '2017-04-13 14:09:19');
INSERT INTO `wd_login_log` VALUES ('53', '1', '0.0.0.0', '2017-04-13 14:09:49', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('54', '1', '0.0.0.0', '2017-04-14 09:05:35', '2017-04-14 14:37:02');
INSERT INTO `wd_login_log` VALUES ('55', '1', '0.0.0.0', '2017-04-14 14:37:05', '2017-04-14 14:40:12');
INSERT INTO `wd_login_log` VALUES ('56', '1', '0.0.0.0', '2017-04-14 14:40:19', '2017-04-14 16:12:49');
INSERT INTO `wd_login_log` VALUES ('57', 'admin', '0.0.0.0', '2017-04-14 16:13:03', '2017-04-14 17:34:28');
INSERT INTO `wd_login_log` VALUES ('58', '2', '0.0.0.0', '2017-04-14 17:34:34', '2017-04-14 17:36:08');
INSERT INTO `wd_login_log` VALUES ('59', '2', '0.0.0.0', '2017-04-14 17:36:12', '2017-04-14 17:37:13');
INSERT INTO `wd_login_log` VALUES ('60', '2', '0.0.0.0', '2017-04-14 17:37:18', '2017-04-14 17:37:24');
INSERT INTO `wd_login_log` VALUES ('61', '1', '0.0.0.0', '2017-04-14 17:37:27', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('62', '1', '0.0.0.0', '2017-04-15 09:09:38', '2017-04-15 11:38:42');
INSERT INTO `wd_login_log` VALUES ('63', '1', '0.0.0.0', '2017-04-15 11:38:49', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('64', '1', '0.0.0.0', '2017-04-15 14:29:20', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('65', '1', '0.0.0.0', '2017-04-15 14:39:20', '2017-04-15 14:51:25');
INSERT INTO `wd_login_log` VALUES ('66', '1', '0.0.0.0', '2017-04-15 14:51:36', '2017-04-15 14:52:16');
INSERT INTO `wd_login_log` VALUES ('67', 'admin', '0.0.0.0', '2017-04-15 14:52:23', '2017-04-15 15:01:39');
INSERT INTO `wd_login_log` VALUES ('68', '1', '0.0.0.0', '2017-04-17 09:12:47', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('69', '1', '0.0.0.0', '2017-04-18 17:30:45', '2017-04-18 19:05:25');
INSERT INTO `wd_login_log` VALUES ('70', 'admin', '0.0.0.0', '2017-04-18 19:05:31', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('71', '1', '0.0.0.0', '2017-04-20 09:42:41', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('72', '1', '0.0.0.0', '2017-04-20 10:12:19', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('73', '1', '0.0.0.0', '2017-04-20 14:43:46', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('74', '1', '0.0.0.0', '2017-04-21 09:13:11', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('75', '1', '0.0.0.0', '2017-04-21 10:50:07', '2017-04-21 11:51:08');
INSERT INTO `wd_login_log` VALUES ('76', '1', '0.0.0.0', '2017-04-21 11:51:13', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('77', '1', '0.0.0.0', '2017-04-21 11:55:00', '2017-04-21 14:04:20');
INSERT INTO `wd_login_log` VALUES ('78', 'admin', '0.0.0.0', '2017-04-21 14:04:32', '2017-04-21 15:28:44');
INSERT INTO `wd_login_log` VALUES ('79', '1', '0.0.0.0', '2017-04-21 15:28:49', '2017-04-21 15:48:49');
INSERT INTO `wd_login_log` VALUES ('80', '1', '0.0.0.0', '2017-04-21 15:48:55', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('81', '1', '0.0.0.0', '2017-04-22 09:24:11', '2017-04-22 15:57:13');
INSERT INTO `wd_login_log` VALUES ('82', '1', '0.0.0.0', '2017-04-22 15:58:21', '2017-04-22 16:00:06');
INSERT INTO `wd_login_log` VALUES ('83', '1', '0.0.0.0', '2017-04-22 16:00:09', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('84', '1', '0.0.0.0', '2017-04-24 16:34:43', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('85', '1', '0.0.0.0', '2017-04-25 17:02:07', '2017-04-25 17:07:06');
INSERT INTO `wd_login_log` VALUES ('86', '1', '0.0.0.0', '2017-04-25 17:07:11', '2017-04-25 17:11:00');
INSERT INTO `wd_login_log` VALUES ('87', '1', '0.0.0.0', '2017-04-25 17:11:10', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('88', '1', '0.0.0.0', '2017-04-25 17:13:30', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('89', '1', '0.0.0.0', '2017-04-25 17:13:49', '0000-00-00 00:00:00');
INSERT INTO `wd_login_log` VALUES ('90', '1', '0.0.0.0', '2017-04-25 17:14:02', '2017-04-25 17:18:53');
INSERT INTO `wd_login_log` VALUES ('91', '1', '0.0.0.0', '2017-04-25 17:24:08', '2017-04-25 17:26:53');
INSERT INTO `wd_login_log` VALUES ('92', '1', '0.0.0.0', '2017-04-25 17:27:07', '2017-04-25 17:27:44');
INSERT INTO `wd_login_log` VALUES ('93', '1', '0.0.0.0', '2017-04-25 17:28:01', '2017-04-25 17:30:14');
INSERT INTO `wd_login_log` VALUES ('94', '1', '0.0.0.0', '2017-04-25 17:30:27', '2017-04-25 17:33:30');
INSERT INTO `wd_login_log` VALUES ('95', '1', '0.0.0.0', '2017-04-25 17:33:40', '2017-04-25 17:36:06');
INSERT INTO `wd_login_log` VALUES ('96', '1', '0.0.0.0', '2017-04-25 17:36:12', '2017-04-25 17:36:31');
INSERT INTO `wd_login_log` VALUES ('97', '1', '0.0.0.0', '2017-04-25 17:38:28', '0000-00-00 00:00:00');

-- -----------------------------
-- Table structure for `wd_message`
-- -----------------------------
DROP TABLE IF EXISTS `wd_message`;
CREATE TABLE `wd_message` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '留言板表',
  `name` varchar(50) NOT NULL COMMENT '留言人名字',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `content` varchar(255) NOT NULL COMMENT '留言内容',
  `time` datetime NOT NULL COMMENT '留言时间',
  `open` tinyint(1) NOT NULL COMMENT '是否公开',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_message`
-- -----------------------------
INSERT INTO `wd_message` VALUES ('2', '留言人', '13637848756', '这是测试文本！', '2017-04-22 15:45:59', '0');
INSERT INTO `wd_message` VALUES ('3', '留言人', '13637848756', '这是测试文本！', '2017-04-22 15:46:01', '0');
INSERT INTO `wd_message` VALUES ('4', '留言人', '13637848756', '这是测试文本！', '2017-04-22 15:46:04', '0');

-- -----------------------------
-- Table structure for `wd_news`
-- -----------------------------
DROP TABLE IF EXISTS `wd_news`;
CREATE TABLE `wd_news` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `sort` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_news`
-- -----------------------------
INSERT INTO `wd_news` VALUES ('8', '微信开发', '0', '3');
INSERT INTO `wd_news` VALUES ('14', '后台搭建', '0', '4');
INSERT INTO `wd_news` VALUES ('18', 'APP开发', '0', '2');
INSERT INTO `wd_news` VALUES ('19', '网站建设', '0', '1');
INSERT INTO `wd_news` VALUES ('20', '测试', '0', '0');
INSERT INTO `wd_news` VALUES ('21', '123', '0', '1');

-- -----------------------------
-- Table structure for `wd_news_content`
-- -----------------------------
DROP TABLE IF EXISTS `wd_news_content`;
CREATE TABLE `wd_news_content` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `pid` int(5) NOT NULL,
  `title` varchar(100) NOT NULL,
  `img_url` varchar(100) NOT NULL,
  `issuer` varchar(100) NOT NULL,
  `time` int(11) NOT NULL,
  `jianjie` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `news_url` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_news_content`
-- -----------------------------
INSERT INTO `wd_news_content` VALUES ('19', '0', '维登', '2017-04-11/58ec8b9844384.jpg', '网站建设', '1491795368', '维登新闻', '维登科技', 'news/news');
INSERT INTO `wd_news_content` VALUES ('20', '3', '标题测试', '2017-04-11/58ecb2a992d3b.jpg', '', '1491795529', '简介测试', '123', 'news/news');
INSERT INTO `wd_news_content` VALUES ('23', '2', '', '2017-04-11/58ecb38d93cdb.jpg', '', '1491907469', '测试', '测试', '');
INSERT INTO `wd_news_content` VALUES ('24', '0', '123', '2017-04-12/58eda707e10d0.jpg', '', '1491969799', '123', '123', '123');

-- -----------------------------
-- Table structure for `wd_service`
-- -----------------------------
DROP TABLE IF EXISTS `wd_service`;
CREATE TABLE `wd_service` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `pid` int(5) NOT NULL,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `icon_url` varchar(100) NOT NULL COMMENT '图标',
  `small_title` varchar(100) NOT NULL COMMENT '图片小标题',
  `list_title` varchar(50) NOT NULL COMMENT '列表标题',
  `classification` varchar(30) NOT NULL COMMENT '分类',
  `list_description` varchar(50) NOT NULL COMMENT '列表描述',
  `content` varchar(150) NOT NULL COMMENT '内容',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_service`
-- -----------------------------
INSERT INTO `wd_service` VALUES ('5', '0', '1', '2017-04-14/58f07193c7067.jpg', '11111111', '111111111', '111111', '11111111111', '&lt;p&gt;1111111111111111111&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '1');
INSERT INTO `wd_service` VALUES ('6', '0', '22', '2017-04-14/58f071aa3b9ef.gif', '2222222', '22222222222', '22222222222', '2322222222222222', '&lt;p&gt;333333333333333333&lt;/p&gt;', '1');

-- -----------------------------
-- Table structure for `wd_service_ce`
-- -----------------------------
DROP TABLE IF EXISTS `wd_service_ce`;
CREATE TABLE `wd_service_ce` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `pid` int(5) NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `sort` int(5) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `div` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_service_ce`
-- -----------------------------
INSERT INTO `wd_service_ce` VALUES ('1', '1', '商城平台开发', 'Mall platform development', '', '商城平台适应PC浏览的网站。通过电脑上的浏览器，输入网址，就可以浏览；可做兼容移动端的。由于电脑端的屏幕尺寸有所不同，专门为电脑各种分辨率进行优化设计网站，更为方便用户浏览。', '0', '0', '量身定制,交互体验,兼容移动端,安全性高');
INSERT INTO `wd_service_ce` VALUES ('2', '1', '软件系统开发', 'Software system development', '', '在互联时代，我们忠于“聚焦客户的关注点，提供有竞争力的解决方案和服务，为客户创造最大价值”的企业理念，根据用户要求建造出软件系统或者系统中的软件部分，创造属于网络时代的精彩互联。', '0', '0', '领先设计,交互体验,量身定制,安全性高,兼容性强');
INSERT INTO `wd_service_ce` VALUES ('3', '1', '品牌型网站开发', 'Brand website development', '', '品牌宣传网站要求独特的个性特征及表现方式，其视觉的定位更需要为品牌服务并符合品牌的文化特征。如今，网站的视觉技术已经由2D、3D到仿真，但更多的还是结合H5、FLASH的应用设计。', '0', '0', '网站规划,网页设计,网页设计,网站系统功能开发');
INSERT INTO `wd_service_ce` VALUES ('4', '2', 'iOS应用开发 ', 'iOS application development', '', 'iOS应用开发安全性高，对硬件有极高的针对性。系统体验好，操作流畅，软件兼容性强。应用多种多样，大多APP应用都是先于安卓出现的。', '0', '0', '电商类,餐饮类,社交类,旅游类,金融类,家政类,医疗类,地产类');
INSERT INTO `wd_service_ce` VALUES ('5', '2', 'Android应用开发', ' Android application development', '', 'Android系统由于是开放源代码，所以支持它的手机很多，可以免费使用的软件也很多，可以不断升级。', '0', '0', '电商类,餐饮类,社交类,旅游类,金融类,家政类,医疗类,地产类');
INSERT INTO `wd_service_ce` VALUES ('6', '2', '手机网站开发', 'Mobile web development', '', '由于手机的页面适用性问题，对于移动终端，有不一样的分辨率与屏幕尺寸，最好让网页的宽度自适应屏幕。手机CUP处理器有限，所以做网页也有精简版和普通版之分。', '0', '0', 'HTML5,CSS3,JavaScript,PHP,JSP,ASP.NET,JAVA,C++');
INSERT INTO `wd_service_ce` VALUES ('7', '3', '公众号开发', 'WeChat Official Accounts', '', '微信公众号是一种主流的线上线下微信互动营销方式，可与QQ账号互通，通过公众号，商家可在微信平台上实现和特定群体的文字、图片、语音、视频的全方位沟通、互动 。', '0', '0', '自定义菜单,微官网,微会员,微活动,微行业,微推送,微服务,微统计');
INSERT INTO `wd_service_ce` VALUES ('8', '3', '微商城开发', 'WeChat mall development', '', '微信商城系统是微信第三方平台基于微信而研发的一款社会化电子商务系统，同时又是一款传统互联网、移动互联网、微信商城、易信商城、APP商城五网一体化的企业购物系统。', '0', '0', '便捷简单,独有会员系统,支付多功能,消费有提醒,活动推广');
INSERT INTO `wd_service_ce` VALUES ('9', '3', '小程序开发', 'WeChat mini programs', '', '微信小程序是一种不需要下载安装即可使用的应用，它实现了应用“触手可及”的梦想，用户扫一扫或者搜一下即可打开应用。也体现了“用完即走”的理念，用户不用关心是否安装太多应用的问题。应用将无处不在，随时可用，但又无需安装卸载。', '0', '0', '便捷简单,触手可及,用完即走,数据分析,第三方平台支持');
INSERT INTO `wd_service_ce` VALUES ('10', '4', '天猫商城 ', ' Tmall', '', '天猫商城是一个综合性购物网站，其整合数千家品牌商、生产商，为商家和消费者之间提供一站式解决方案。', '0', '0', '店铺装修,店铺推广,店铺运营,店铺活动,维护');
INSERT INTO `wd_service_ce` VALUES ('11', '4', '京东商城', 'Jingdong Online Mall', '', '京东是中国最大的综合网络零售商，在线销售家电、数码通讯、电脑、家居百货、服装服饰、母婴、图书、食品、在线旅游等12大类数万个品牌百万种优质商品。', '0', '0', '店铺装修,店铺推广,店铺运营,店铺活动,维护');
INSERT INTO `wd_service_ce` VALUES ('12', '4', '微信托管运营', 'WeChat operation', '', '通过为合作伙伴提供“连接一切”的能力，微信正在形成一个全新的“智慧型”生活方式。其已经渗透进入以下传统行业，如微信打车、微信交电费、微信购物、微信医疗、微信酒店等。', '0', '0', '微信公众号,微官网,微商城,微活动,微行业');

-- -----------------------------
-- Table structure for `wd_service_list`
-- -----------------------------
DROP TABLE IF EXISTS `wd_service_list`;
CREATE TABLE `wd_service_list` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `img_url` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `create_time` datetime NOT NULL COMMENT '发布时间',
  `jianjie` varchar(100) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_service_list`
-- -----------------------------
INSERT INTO `wd_service_list` VALUES ('34', '服务', '2017-04-13/58eee573ee3c2.gif', '&lt;p&gt;&amp;lt;p&amp;gt;&amp;amp;lt;p&amp;amp;gt;服务服务服务服务服务服务服务服务服务服务&amp;amp;lt;/p&amp;amp;gt;&amp;lt;/p&amp;gt;&lt;/p&gt;', '2017-04-13 15:11:33', '服务服务服务', '1');
INSERT INTO `wd_service_list` VALUES ('35', '1', '2017-04-14/58f070fe10687.gif', '&lt;p&gt;88888888888888888888888&lt;/p&gt;', '2017-04-14 14:49:34', '88888888888', '1');

-- -----------------------------
-- Table structure for `wd_service_title`
-- -----------------------------
DROP TABLE IF EXISTS `wd_service_title`;
CREATE TABLE `wd_service_title` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `sort` int(3) NOT NULL,
  `state` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_service_title`
-- -----------------------------
INSERT INTO `wd_service_title` VALUES ('1', 'pc.png', 'pc端开发', '0', '0');
INSERT INTO `wd_service_title` VALUES ('2', 'yd.png', '手机应用开发', '0', '0');
INSERT INTO `wd_service_title` VALUES ('3', 'wx.png', '微信二次开发', '0', '0');
INSERT INTO `wd_service_title` VALUES ('4', 'wh.png', '运营维护', '0', '0');

-- -----------------------------
-- Table structure for `wd_visit_log`
-- -----------------------------
DROP TABLE IF EXISTS `wd_visit_log`;
CREATE TABLE `wd_visit_log` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '网页访问表',
  `ip` varchar(20) NOT NULL COMMENT '访问ip',
  `time` datetime NOT NULL COMMENT '访问时间',
  `shua` int(5) NOT NULL DEFAULT '1',
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_visit_log`
-- -----------------------------
INSERT INTO `wd_visit_log` VALUES ('9', '0.0.0.0', '2017-04-20 14:13:27', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('10', '0.0.0.0', '2017-04-20 14:32:05', '5', '0');
INSERT INTO `wd_visit_log` VALUES ('11', '0.0.0.0', '2017-04-20 14:40:35', '4', '0');
INSERT INTO `wd_visit_log` VALUES ('12', '0.0.0.0', '2017-04-20 14:41:07', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('13', '0.0.0.0', '2017-04-20 15:43:09', '5', '0');
INSERT INTO `wd_visit_log` VALUES ('14', '0.0.0.0', '2017-04-21 09:13:03', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('15', '0.0.0.0', '2017-04-21 10:27:09', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('16', '0.0.0.0', '2017-04-21 10:55:35', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('17', '0.0.0.0', '2017-04-21 11:45:34', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('18', '0.0.0.0', '2017-04-21 11:55:00', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('19', '', '2017-04-12 11:55:00', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('20', '0.0.0.0', '2017-04-21 14:01:02', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('21', '0.0.0.0', '2017-04-21 14:04:32', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('22', '0.0.0.0', '2017-04-21 14:13:48', '2', '0');
INSERT INTO `wd_visit_log` VALUES ('23', '0.0.0.0', '2017-04-21 15:28:49', '5', '1');
INSERT INTO `wd_visit_log` VALUES ('24', '0.0.0.0', '2017-04-21 15:46:33', '2', '0');
INSERT INTO `wd_visit_log` VALUES ('25', '0.0.0.0', '2017-04-21 15:48:55', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('26', '0.0.0.0', '2017-04-21 15:56:24', '11', '0');
INSERT INTO `wd_visit_log` VALUES ('27', '0.0.0.0', '2017-04-21 16:34:33', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('28', '0.0.0.0', '2017-04-21 16:46:39', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('29', '0.0.0.0', '2017-04-21 16:57:41', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('30', '0.0.0.0', '2017-04-21 17:07:38', '7', '0');
INSERT INTO `wd_visit_log` VALUES ('31', '0.0.0.0', '2017-04-21 17:25:23', '7', '0');
INSERT INTO `wd_visit_log` VALUES ('32', '0.0.0.0', '2017-04-21 17:51:23', '3', '0');
INSERT INTO `wd_visit_log` VALUES ('33', '0.0.0.0', '2017-04-22 09:23:58', '5', '0');
INSERT INTO `wd_visit_log` VALUES ('34', '0.0.0.0', '2017-04-22 09:24:11', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('35', '0.0.0.0', '2017-04-22 09:48:24', '11', '0');
INSERT INTO `wd_visit_log` VALUES ('36', '0.0.0.0', '2017-04-22 10:20:08', '7', '0');
INSERT INTO `wd_visit_log` VALUES ('37', '0.0.0.0', '2017-04-22 10:33:29', '8', '0');
INSERT INTO `wd_visit_log` VALUES ('38', '0.0.0.0', '2017-04-22 10:46:08', '4', '0');
INSERT INTO `wd_visit_log` VALUES ('39', '0.0.0.0', '2017-04-22 11:28:14', '4', '0');
INSERT INTO `wd_visit_log` VALUES ('40', '0.0.0.0', '2017-04-22 11:43:58', '7', '0');
INSERT INTO `wd_visit_log` VALUES ('41', '0.0.0.0', '2017-04-22 11:53:06', '11', '0');
INSERT INTO `wd_visit_log` VALUES ('42', '0.0.0.0', '2017-04-22 14:02:01', '44', '0');
INSERT INTO `wd_visit_log` VALUES ('43', '0.0.0.0', '2017-04-22 14:50:13', '10', '0');
INSERT INTO `wd_visit_log` VALUES ('44', '0.0.0.0', '2017-04-22 15:13:14', '3', '0');
INSERT INTO `wd_visit_log` VALUES ('45', '0.0.0.0', '2017-04-22 15:30:12', '2', '0');
INSERT INTO `wd_visit_log` VALUES ('46', '0.0.0.0', '2017-04-22 15:58:21', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('47', '0.0.0.0', '2017-04-22 16:00:09', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('48', '0.0.0.0', '2017-04-22 16:00:59', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('49', '0.0.0.0', '2017-04-22 16:20:23', '10', '0');
INSERT INTO `wd_visit_log` VALUES ('50', '0.0.0.0', '2017-04-22 16:34:50', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('51', '0.0.0.0', '2017-04-24 16:34:30', '2', '0');
INSERT INTO `wd_visit_log` VALUES ('52', '0.0.0.0', '2017-04-24 16:34:43', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('53', '0.0.0.0', '2017-04-24 18:01:49', '1', '0');
INSERT INTO `wd_visit_log` VALUES ('54', '0.0.0.0', '2017-04-25 09:40:06', '9', '0');
INSERT INTO `wd_visit_log` VALUES ('55', '0.0.0.0', '2017-04-25 17:02:07', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('56', '0.0.0.0', '2017-04-25 17:07:11', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('57', '0.0.0.0', '2017-04-25 17:11:10', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('58', '0.0.0.0', '2017-04-25 17:11:48', '2', '0');
INSERT INTO `wd_visit_log` VALUES ('59', '0.0.0.0', '2017-04-25 17:13:30', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('60', '0.0.0.0', '2017-04-25 17:13:49', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('61', '0.0.0.0', '2017-04-25 17:14:02', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('62', '0.0.0.0', '2017-04-25 17:24:08', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('63', '0.0.0.0', '2017-04-25 17:27:07', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('64', '0.0.0.0', '2017-04-25 17:28:01', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('65', '0.0.0.0', '2017-04-25 17:30:27', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('66', '0.0.0.0', '2017-04-25 17:33:40', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('67', '0.0.0.0', '2017-04-25 17:36:12', '1', '1');
INSERT INTO `wd_visit_log` VALUES ('68', '0.0.0.0', '2017-04-25 17:38:28', '1', '1');

-- -----------------------------
-- Table structure for `wd_web`
-- -----------------------------
DROP TABLE IF EXISTS `wd_web`;
CREATE TABLE `wd_web` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '网站信息表',
  `web_name` varchar(100) NOT NULL COMMENT '网站名',
  `web_ip` varchar(100) NOT NULL COMMENT '网站域名',
  `web_logo` varchar(255) NOT NULL COMMENT '网站logo',
  `web_logo_small` varchar(100) NOT NULL COMMENT '网站小图标',
  `web_author` varchar(50) NOT NULL COMMENT '创建者',
  `seo` varchar(255) NOT NULL COMMENT 'SEO',
  `web_miaoshu` varchar(255) NOT NULL COMMENT '网站描述',
  `web_banquan` varchar(255) NOT NULL COMMENT '版权信息',
  `keyword` varchar(255) NOT NULL COMMENT '关键词做推广',
  `web_state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '网站状态（是否开启）',
  `ico` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wd_web`
-- -----------------------------
INSERT INTO `wd_web` VALUES ('1', '维登信息科技', 'www.wheden.cn', '2017-04-13/58ef1793185e2.png', '2017-04-14/58f0395cd52f7.png', '李先生', 'SEO', '商城平台开发、手机网站开发、微信公众号开发', '版权 © 2016-2017 东莞市维登信息科技有限公司', '网站设计、网站推广', '0', '');
